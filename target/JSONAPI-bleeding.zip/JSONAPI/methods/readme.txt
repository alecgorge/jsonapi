put custom methods in here, in the same format as ../methods.json

reload plugin for changes to come into effect